# buku_kehadiran.py
# CLASS 3: BukuKehadiran (Manajemen Tabel)
# Konsep OOP: Komposisi (memiliki Pandas DataFrame di dalamnya)

import pandas as pd
import os
from datetime import datetime


class BukuKehadiran:
    TOTAL_PERTEMUAN = 16
    FILE_SIMPAN = "data_kehadiran.csv"

    def __init__(self):
        self.__tabel = None  # Pandas DataFrame

    def buat_tabel_daftar_mahasiswa(self, list_mahasiswa: list):
        """Inisialisasi tabel. Semua status awal = 'Alpha'. Muat dari CSV jika sudah ada."""
        if os.path.exists(self.FILE_SIMPAN):
            self.__tabel = pd.read_csv(self.FILE_SIMPAN, dtype=str)
            print(f"[INFO] Tabel kehadiran dimuat dari '{self.FILE_SIMPAN}'.")
        else:
            kolom = ["NIM", "Nama"] + [f"Pertemuan {i}" for i in range(1, self.TOTAL_PERTEMUAN + 1)]
            baris = []
            for mhs in list_mahasiswa:
                row = {"NIM": mhs.nim, "Nama": mhs.nama}
                for i in range(1, self.TOTAL_PERTEMUAN + 1):
                    row[f"Pertemuan {i}"] = "Alpha"
                baris.append(row)
            self.__tabel = pd.DataFrame(baris, columns=kolom)
            self.__simpan_ke_csv()
            print("[OK] Tabel kehadiran berhasil dibuat.")

    def tambah_mahasiswa_baru(self, mahasiswa):
        """Tambah baris baru ke tabel untuk mahasiswa yang baru diregistrasi."""
        if self.__tabel is None:
            return
        if mahasiswa.nim in self.__tabel["NIM"].values:
            return
        row = {"NIM": mahasiswa.nim, "Nama": mahasiswa.nama}
        for i in range(1, self.TOTAL_PERTEMUAN + 1):
            row[f"Pertemuan {i}"] = "Alpha"
        baris_baru = pd.DataFrame([row])
        self.__tabel = pd.concat([self.__tabel, baris_baru], ignore_index=True)
        self.__simpan_ke_csv()

    def catat_hadir(self, nim: str, pertemuan_ke: int) -> bool:
        """Ubah status Pertemuan X milik NIM menjadi 'Hadir (HH:MM)'."""
        if self.__tabel is None:
            print("[ERROR] Tabel belum dibuat. Jalankan inisialisasi tabel dulu.")
            return False

        kolom = f"Pertemuan {pertemuan_ke}"
        mask = self.__tabel["NIM"] == nim

        if not mask.any():
            print(f"[ERROR] NIM {nim} tidak ditemukan di tabel.")
            return False

        jam = datetime.now().strftime("%H:%M")
        self.__tabel.loc[mask, kolom] = f"Hadir ({jam})"
        self.__simpan_ke_csv()
        return True

    def tampilkan_rekap(self):
        """Print tabel kehadiran secara rapi di terminal."""
        if self.__tabel is None:
            print("[INFO] Tabel belum dibuat.")
            return
        print("\n" + "=" * 60)
        print("         REKAP KEHADIRAN MAHASISWA")
        print("=" * 60)
        pd.set_option("display.max_columns", None)
        pd.set_option("display.width", None)
        pd.set_option("display.max_colwidth", 15)
        print(self.__tabel.to_string(index=False))
        print("=" * 60 + "\n")

    def __simpan_ke_csv(self):
        if self.__tabel is not None:
            self.__tabel.to_csv(self.FILE_SIMPAN, index=False)
