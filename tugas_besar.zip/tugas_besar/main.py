# main.py
# Entry point — jalankan file ini untuk memulai aplikasi

from aplikasi_absensi import AplikasiAbsensi

if __name__ == "__main__":
    app = AplikasiAbsensi()
    app.jalankan()
