# face_engine.py
# CLASS 2: FaceEngine (Otak AI)
# Konsep OOP: Facade Pattern

import cv2
import face_recognition
import os
from datetime import datetime


class FaceEngine:
    def __init__(self, toleransi: float = 0.5):
        self.toleransi = toleransi

    def ambil_foto_kamera(self, simpan_ke: str = None) -> str | None:
        """Buka kamera, tekan SPACE/ENTER untuk jepret. Kembalikan path foto."""
        print("\n[KAMERA] Kamera menyala. Hadapkan wajah ke kamera.")
        print("         Tekan SPACE atau ENTER untuk mengambil foto.")
        print("         Tekan ESC untuk batal.\n")

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[ERROR] Kamera tidak dapat dibuka!")
            return None

        foto_path = None
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[ERROR] Gagal membaca frame kamera.")
                break

            tampilan = frame.copy()
            cv2.putText(tampilan, "Tekan SPACE/ENTER untuk foto | ESC batal",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.imshow("Kamera Absensi - Posisikan Wajah", tampilan)

            key = cv2.waitKey(1) & 0xFF
            if key in [32, 13]:  # SPACE atau ENTER
                if simpan_ke is None:
                    os.makedirs("data_foto", exist_ok=True)
                    simpan_ke = f"data_foto/foto_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
                else:
                    os.makedirs(os.path.dirname(simpan_ke), exist_ok=True)
                cv2.imwrite(simpan_ke, frame)
                print(f"[OK] Foto disimpan: {simpan_ke}")
                foto_path = simpan_ke
                break
            elif key == 27:  # ESC
                print("[BATAL] Pengambilan foto dibatalkan.")
                break

        cap.release()
        cv2.destroyAllWindows()
        return foto_path

    def ekstrak_vektor(self, foto_path: str):
        """Ubah gambar menjadi vektor wajah. Kembalikan vektor atau None."""
        gambar = face_recognition.load_image_file(foto_path)
        daftar_vektor = face_recognition.face_encodings(gambar)

        if len(daftar_vektor) == 0:
            print(f"[WARNING] Tidak ada wajah terdeteksi di foto: {foto_path}")
            return None
        if len(daftar_vektor) > 1:
            print(f"[WARNING] {len(daftar_vektor)} wajah terdeteksi. Menggunakan wajah pertama.")

        return daftar_vektor[0]

    def cocokkan_wajah(self, vektor_kamera, database_mahasiswa: list):
        """Bandingkan vektor_kamera dengan semua data di database. Kembalikan objek Mahasiswa atau None."""
        if vektor_kamera is None:
            return None

        for mhs in database_mahasiswa:
            if mhs.vektor_wajah is None:
                continue
            hasil = face_recognition.compare_faces(
                [mhs.vektor_wajah], vektor_kamera, tolerance=self.toleransi
            )
            if hasil[0]:
                return mhs

        return None

    def scan_wajah_dari_kamera(self, database_mahasiswa: list):
        """Buka kamera live, scan wajah, kembalikan objek Mahasiswa jika dikenali."""
        print("\n[SCAN] Kamera menyala untuk scan absensi.")
        print("       Tekan SPACE/ENTER untuk scan wajah yang tampil.")
        print("       Tekan ESC untuk selesai scan.\n")

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("[ERROR] Kamera tidak dapat dibuka!")
            return None

        hasil_mahasiswa = None
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            tampilan = frame.copy()
            cv2.putText(tampilan, "SPACE/ENTER: Scan | ESC: Selesai",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            cv2.imshow("Scan Absensi", tampilan)

            key = cv2.waitKey(1) & 0xFF
            if key in [32, 13]:
                tmp_path = "data_foto/_tmp_scan.jpg"
                os.makedirs("data_foto", exist_ok=True)
                cv2.imwrite(tmp_path, frame)

                vektor = self.ekstrak_vektor(tmp_path)
                mahasiswa = self.cocokkan_wajah(vektor, database_mahasiswa)

                if mahasiswa:
                    print(f"\n[DIKENALI] ✓ {mahasiswa.nama} ({mahasiswa.nim})")
                    hasil_mahasiswa = mahasiswa
                    break
                else:
                    print("[TIDAK DIKENALI] ✗ Wajah tidak ada di database. Coba lagi.")

            elif key == 27:
                print("[SELESAI] Scan dihentikan.")
                break

        cap.release()
        cv2.destroyAllWindows()
        return hasil_mahasiswa
