# aplikasi_absensi.py
# CLASS 4: AplikasiAbsensi (Controller / Pengendali Utama)
# Konsep OOP: Komposisi — menyatukan semua class

import os
import pickle

from mahasiswa import Mahasiswa
from face_engine import FaceEngine
from buku_kehadiran import BukuKehadiran


class AplikasiAbsensi:
    FILE_DATABASE = "data_mahasiswa.pkl"

    def __init__(self):
        self.__face_engine = FaceEngine(toleransi=0.5)
        self.__buku_kehadiran = BukuKehadiran()
        self.__database_mahasiswa: list[Mahasiswa] = []
        self.__muat_database()

    # --- Database ---
    def __muat_database(self):
        if os.path.exists(self.FILE_DATABASE):
            with open(self.FILE_DATABASE, "rb") as f:
                self.__database_mahasiswa = pickle.load(f)
            print(f"[INFO] Database dimuat: {len(self.__database_mahasiswa)} mahasiswa terdaftar.")
        else:
            print("[INFO] Database kosong. Silakan registrasi mahasiswa terlebih dahulu.")

    def __simpan_database(self):
        with open(self.FILE_DATABASE, "wb") as f:
            pickle.dump(self.__database_mahasiswa, f)

    # --- Menu 1: Registrasi ---
    def menu_registrasi(self):
        print("\n" + "=" * 40)
        print("       MENU REGISTRASI MAHASISWA")
        print("=" * 40)

        nim = input("Masukkan NIM   : ").strip()
        if not nim:
            print("[BATAL] NIM tidak boleh kosong.")
            return

        for mhs in self.__database_mahasiswa:
            if mhs.nim == nim:
                print(f"[ERROR] NIM {nim} sudah terdaftar atas nama {mhs.nama}.")
                return

        nama = input("Masukkan Nama  : ").strip()
        if not nama:
            print("[BATAL] Nama tidak boleh kosong.")
            return

        foto_path = f"data_foto/{nim}.jpg"
        foto_path = self.__face_engine.ambil_foto_kamera(simpan_ke=foto_path)
        if foto_path is None:
            print("[BATAL] Registrasi dibatalkan karena foto gagal diambil.")
            return

        print("[PROSES] Mengekstrak vektor wajah...")
        vektor = self.__face_engine.ekstrak_vektor(foto_path)
        if vektor is None:
            print("[ERROR] Wajah tidak terdeteksi. Coba registrasi ulang dengan pencahayaan lebih baik.")
            return

        mhs_baru = Mahasiswa(nim, nama, foto_path, vektor)
        self.__database_mahasiswa.append(mhs_baru)
        self.__simpan_database()
        self.__buku_kehadiran.tambah_mahasiswa_baru(mhs_baru)

        print(f"\n[SUKSES] ✓ {nama} ({nim}) berhasil diregistrasi!")

    # --- Menu 2: Absensi ---
    def menu_absensi(self):
        print("\n" + "=" * 40)
        print("         MENU ABSENSI")
        print("=" * 40)

        if not self.__database_mahasiswa:
            print("[ERROR] Belum ada mahasiswa terdaftar. Lakukan registrasi dulu.")
            return

        try:
            pertemuan_ke = int(input("Pertemuan ke berapa? (1-16): ").strip())
            if not 1 <= pertemuan_ke <= 16:
                print("[ERROR] Pertemuan harus antara 1 sampai 16.")
                return
        except ValueError:
            print("[ERROR] Input harus angka.")
            return

        print(f"\n[INFO] Memulai absensi Pertemuan {pertemuan_ke}...")

        while True:
            mahasiswa = self.__face_engine.scan_wajah_dari_kamera(self.__database_mahasiswa)
            if mahasiswa is None:
                break

            berhasil = self.__buku_kehadiran.catat_hadir(mahasiswa.nim, pertemuan_ke)
            if berhasil:
                print(f"[CATAT] Kehadiran {mahasiswa.nama} di Pertemuan {pertemuan_ke} berhasil dicatat.\n")

            lanjut = input("Scan mahasiswa berikutnya? (y/n): ").strip().lower()
            if lanjut != "y":
                break

        print(f"\n[SELESAI] Sesi absensi Pertemuan {pertemuan_ke} selesai.")

    # --- Menu 3: Inisialisasi Tabel ---
    def menu_inisialisasi_tabel(self):
        print("\n" + "=" * 40)
        print("     INISIALISASI TABEL KEHADIRAN")
        print("=" * 40)

        if not self.__database_mahasiswa:
            print("[ERROR] Belum ada mahasiswa terdaftar. Lakukan registrasi dulu.")
            return

        konfirmasi = input("Ini akan membuat/mereset tabel kehadiran. Lanjutkan? (y/n): ").strip().lower()
        if konfirmasi != "y":
            print("[BATAL] Inisialisasi dibatalkan.")
            return

        self.__buku_kehadiran.buat_tabel_daftar_mahasiswa(self.__database_mahasiswa)

    # --- Menu 4: Lihat Rekap ---
    def menu_lihat_rekap(self):
        self.__buku_kehadiran.tampilkan_rekap()

    # --- Menu 5: Lihat Daftar Mahasiswa ---
    def menu_lihat_mahasiswa(self):
        print("\n" + "=" * 40)
        print("    DAFTAR MAHASISWA TERDAFTAR")
        print("=" * 40)
        if not self.__database_mahasiswa:
            print("[INFO] Belum ada mahasiswa terdaftar.")
        for i, mhs in enumerate(self.__database_mahasiswa, 1):
            print(f"  {i}. {mhs.nama} ({mhs.nim})")
        print()

    # --- Loop Utama ---
    def jalankan(self):
        print("\n" + "=" * 50)
        print("   APLIKASI ABSENSI FACE RECOGNITION")
        print("   Konsep OOP - Tugas Besar")
        print("=" * 50)

        while True:
            print("\n--- MENU UTAMA ---")
            print("  1. Registrasi Mahasiswa (Enrollment)")
            print("  2. Mulai Absensi (Face Scan)")
            print("  3. Inisialisasi Tabel Kehadiran")
            print("  4. Lihat Rekap Kehadiran")
            print("  5. Lihat Daftar Mahasiswa Terdaftar")
            print("  0. Keluar")
            print("-" * 20)

            pilihan = input("Pilih menu: ").strip()

            if pilihan == "1":
                self.menu_registrasi()
            elif pilihan == "2":
                self.menu_absensi()
            elif pilihan == "3":
                self.menu_inisialisasi_tabel()
            elif pilihan == "4":
                self.menu_lihat_rekap()
            elif pilihan == "5":
                self.menu_lihat_mahasiswa()
            elif pilihan == "0":
                print("\n[KELUAR] Sampai jumpa!\n")
                break
            else:
                print("[ERROR] Pilihan tidak valid. Masukkan angka 0-5.")
