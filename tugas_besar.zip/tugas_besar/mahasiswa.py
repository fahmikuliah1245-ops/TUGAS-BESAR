# mahasiswa.py
# CLASS 1: Mahasiswa (Entitas Data)
# Konsep OOP: Encapsulation

class Mahasiswa:
    def __init__(self, nim: str, nama: str, foto_path: str = None, vektor_wajah=None):
        self.__nim = nim
        self.__nama = nama
        self.__foto_path = foto_path
        self.__vektor_wajah = vektor_wajah

    @property
    def nim(self):
        return self.__nim

    @property
    def nama(self):
        return self.__nama

    @property
    def foto_path(self):
        return self.__foto_path

    @property
    def vektor_wajah(self):
        return self.__vektor_wajah

    @foto_path.setter
    def foto_path(self, path):
        self.__foto_path = path

    @vektor_wajah.setter
    def vektor_wajah(self, vektor):
        self.__vektor_wajah = vektor

    def __str__(self):
        return f"Mahasiswa(NIM={self.__nim}, Nama={self.__nama})"
